define(function() {

return ( /([a-z])\1*|'([^']|'')+'|''|./ig );

});
