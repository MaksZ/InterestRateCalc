define(function() {

return [ "sun", "mon", "tue", "wed", "thu", "fri", "sat" ];

});
