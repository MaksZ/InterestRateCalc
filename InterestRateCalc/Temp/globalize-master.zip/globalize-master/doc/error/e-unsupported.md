## E_UNSUPPORTED

Thrown for unsupported features, eg. to format unsupported date patterns.

Error object:

| Attribute | Value |
| --- | --- |
| code | `E_UNSUPPORTED` |
| feature | Description of the unsupported feature |
